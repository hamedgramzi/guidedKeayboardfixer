##GuidedStepFragment Examples
 Showcase of the new features offered by the [Leanback support Library](http://developer.android.com/tools/support-library/features.html#v17-leanback), specifically on the [GuidedStepFragment](https://developer.android.com/reference/android/support/v17/leanback/app/GuidedStepFragment.html).


[Download a demo apk here](demo.apk)

![screenshot](guided_step_fragment.png)
